package z.nova.rifmobolgame.Model;

public class TextLevel {


        private String name;

        public TextLevel(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

}
